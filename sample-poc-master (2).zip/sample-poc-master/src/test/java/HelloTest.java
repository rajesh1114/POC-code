import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class HelloTest {

    @Test
    public void hello_first_test_case() {
        assertTrue(true);
//        fail("เขียนชุดการทดสอบสิ");
    }

}
