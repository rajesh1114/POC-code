package api.servlet;

public class UserModel {
    public User getUser() {
        return new User("1111", "Up1");
    }
}
